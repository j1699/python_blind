import cv2
import pyzbar.pyzbar as pyzbar
from gtts import gTTS
import os
import time
from playsound import playsound
os.chdir("c:/Users/Administrator/Desktop/blind")

# text라는 문자열을 음원파일로 저장후 재생
def speak(text):
    tts = gTTS(text=text, lang='ko',slow=False)
    filename ='C:/Users/Administrator/Desktop/blind/speech.mp3'
    tts.save(filename)
    time.sleep(1)
    playsound(filename)
    os.remove(filename)

# 리스트 생성
used_codes = []
data_list = []

#txt파일 생성
try:
    f = open("qrbarcode_data.txt", "r", encoding="utf8")
    data_list = f.readlines()
except FileNotFoundError:
    pass
else:
    f.close()

cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

for i in data_list:
    used_codes.append(i.rstrip('\n'))

# QR인식
while True:
    success, frame = cap.read()
    
    for code in pyzbar.decode(frame):
        cv2.imwrite('qrbarcode_image.png', frame)
        my_code = code.data.decode('utf-8')
        beepsound = "C:/Users/Administrator/Desktop/blind/qrbarcode_beep.mp3"
        if my_code not in used_codes:
            print("인식 성공 : ", my_code)
            playsound(beepsound)
            used_codes.append(my_code)

            f2 = open("qrbarcode_data.txt", "a", encoding="utf8")
            f2.write(my_code+'\n')
            f2.close()
                
            speak(my_code)
            
            time.sleep(1)
            
        elif my_code in used_codes:
            print("이미 인식된 코드입니다!!!")
            playsound(beepsound)
            
            time.sleep(1)
            
        else:
            pass

    cv2.imshow('QRcode Barcode Scan', frame)

    key = cv2.waitKey(1)
    if key == 27:
        break